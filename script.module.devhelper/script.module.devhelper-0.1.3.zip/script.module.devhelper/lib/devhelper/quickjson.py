import sys
if sys.version_info < (2, 7):
    import simplejson as json
else:
    import json

import pykodi
from pykodi import log

movie_properties = ['file', 'title', 'genre', 'year', 'rating', 'playcount', 'runtime', 'lastplayed', 'plot', 'art',
    'resume', 'dateadded', 'mpaa', 'imdbnumber', 'plotoutline', 'tagline']
episode_properties = ['file', 'title', 'firstaired', 'lastplayed', 'episode', 'season', 'plot', 'art', 'resume',
    'playcount', 'dateadded', 'runtime', 'tvshowid', 'uniqueid', 'showtitle']
tvshow_properties = ['file', 'title', 'lastplayed', 'plot', 'art', 'playcount', 'dateadded', 'mpaa', 'genre',
    'imdbnumber', 'year']
musicvideos_properties = ['file', 'title', 'album', 'artist', 'genre', 'year', 'lastplayed', 'plot', 'art', 'resume',
    'playcount', 'dateadded', 'runtime']

# userrating added in Jarvis
all_movie_properties = ['title', 'genre', 'year', 'rating', 'director', 'trailer', 'tagline', 'plot', 'plotoutline',
    'originaltitle', 'lastplayed', 'playcount', 'writer', 'studio', 'mpaa', 'cast', 'country', 'imdbnumber', 'runtime',
    'set', 'showlink', 'streamdetails', 'top250', 'votes', 'fanart', 'thumbnail', 'file', 'sorttitle', 'resume',
    'setid', 'dateadded', 'tag', 'art', 'userrating']
all_tvshow_properties = ['title', 'genre', 'year', 'rating', 'plot', 'studio', 'mpaa', 'cast', 'playcount', 'episode',
    'imdbnumber', 'premiered', 'votes', 'lastplayed', 'fanart', 'thumbnail', 'file', 'originaltitle', 'sorttitle',
    'episodeguide', 'season', 'watchedepisodes', 'dateadded', 'tag', 'art', 'userrating']
all_episode_properties = ['title', 'plot', 'votes', 'rating', 'writer', 'firstaired', 'playcount', 'runtime',
    'director', 'productioncode', 'season', 'episode', 'originaltitle', 'showtitle', 'cast', 'streamdetails',
    'lastplayed', 'fanart', 'thumbnail', 'file', 'resume', 'tvshowid', 'dateadded', 'uniqueid', 'art',
    'specialsortseason', 'specialsortepisode', 'userrating']

inprogress_filter = {'field': 'inprogress', 'operator':'true', 'value':''}
recentlyplayed_filter = {'field': 'lastplayed', 'operator': 'inthelast', 'value': '28'}
recentlyadded_filter = {'field': 'dateadded', 'operator': 'inthelast', 'value': '28'}
unplayed_filter = {'field': 'playcount', 'operator': 'lessthan', 'value':'1'}
played_filter = {'field': 'playcount', 'operator': 'greaterthan', 'value':'0'}

def get_movie_details(movie_id, properties=None):
    json_request = get_base_json_request('VideoLibrary.GetMovieDetails')
    json_request['params']['movieid'] = movie_id
    json_request['params']['properties'] = properties if properties is not None else movie_properties

    json_result = pykodi.execute_jsonrpc(json_request)

    if _check_json_result(json_result, 'moviedetails', json_request):
        return json_result['result']['moviedetails']

def get_tvshow_details(tvshow_id, properties=None):
    json_request = get_base_json_request('VideoLibrary.GetTVShowDetails')
    json_request['params']['tvshowid'] = tvshow_id
    json_request['params']['properties'] = properties if properties is not None else tvshow_properties

    json_result = pykodi.execute_jsonrpc(json_request)

    if _check_json_result(json_result, 'tvshowdetails', json_request):
        return json_result['result']['tvshowdetails']

def get_episode_details(episode_id, properties=None):
    json_request = get_base_json_request('VideoLibrary.GetEpisodeDetails')
    json_request['params']['episodeid'] = episode_id
    json_request['params']['properties'] = properties if properties is not None else episode_properties

    json_result = pykodi.execute_jsonrpc(json_request)

    if _check_json_result(json_result, 'episodedetails', json_request):
        return json_result['result']['episodedetails']

def get_movies(sort_method='sorttitle', ascending=True, limit=None, properties=None, moviefilter=None):
    json_request = get_base_json_request('VideoLibrary.GetMovies')
    json_request['params']['properties'] = properties if properties is not None else movie_properties
    json_request['params']['sort'] = {'method': sort_method, 'order': 'ascending' if ascending else 'descending'}
    if limit:
        json_request['params']['limits'] = {'end': limit}
    if moviefilter:
        json_request['params']['filter'] = moviefilter

    json_result = pykodi.execute_jsonrpc(json_request)
    if _check_json_result(json_result, 'movies', json_request):
        return json_result['result']['movies']
    else:
        return []

def get_tvshows(sort_method='sorttitle', ascending=True, limit=None, properties=None, seriesfilter=None):
    json_request = get_base_json_request('VideoLibrary.GetTVShows')
    json_request['params']['properties'] = properties if properties is not None else tvshow_properties
    json_request['params']['sort'] = {'method': sort_method, 'order': 'ascending' if ascending else 'descending'}
    if limit:
        json_request['params']['limits'] = {'end': limit}
    if seriesfilter:
        json_request['params']['filter'] = seriesfilter

    json_result = pykodi.execute_jsonrpc(json_request)
    if _check_json_result(json_result, 'tvshows', json_request):
        return json_result['result']['tvshows']
    else:
        return []

def get_episodes(tvshow_id=None, sort_method='episode', ascending=True, limit=None, properties=None, episodefilter=None):
    json_request = get_base_json_request('VideoLibrary.GetEpisodes')
    if tvshow_id:
        json_request['params']['tvshowid'] = tvshow_id
    json_request['params']['properties'] = properties if properties is not None else episode_properties
    json_request['params']['sort'] = {'method': sort_method, 'order': 'ascending' if ascending else 'descending'}
    if limit:
        json_request['params']['limits'] = {'end': limit}
    if episodefilter:
        json_request['params']['filter'] = episodefilter

    json_result = pykodi.execute_jsonrpc(json_request)
    if _check_json_result(json_result, 'episodes', json_request):
        return json_result['result']['episodes']
    else:
        return []

def get_recentlyadded_movies(recent_days=28):
    if recent_days == 28:
        moviefilter = recentlyadded_filter
    else:
        moviefilter = dict(recentlyadded_filter)
        moviefilter['value'] = '%s' % recent_days
    return get_movies('dateadded', False, moviefilter=moviefilter)

def get_recentlyplayed_movies(recent_days=28, inprogress=False):
    if recent_days == 28:
        moviefilter = recentlyplayed_filter
    else:
        moviefilter = dict(recentlyplayed_filter)
        moviefilter['value'] = '%s' % recent_days
    if inprogress:
        moviefilter = filter_and(moviefilter, inprogress_filter)
    return get_movies('dateadded', False, moviefilter=moviefilter)

def get_inprogress_tvshows():
    return get_tvshows('lastplayed', False, seriesfilter=filter_and(inprogress_filter, recentlyplayed_filter))

def get_recentlyplayed_tvshows(recent_days=28):
    if recent_days == 28:
        seriesfilter = recentlyplayed_filter
    else:
        seriesfilter = dict(recentlyplayed_filter)
        seriesfilter['value'] = '%s' % recent_days
    return get_tvshows('lastplayed', False, seriesfilter=seriesfilter)

def get_recentlyadded_tvshows(recent_days=28):
    if recent_days == 28:
        seriesfilter = recentlyadded_filter
    else:
        seriesfilter = dict(recentlyadded_filter)
        seriesfilter['value'] = '%s' % recent_days
    return get_tvshows('dateadded', False, seriesfilter=seriesfilter)

def get_recentlyplayed_episodes(tvshow_id=None, recent_days=28):
    if recent_days == 28:
        episodefilter = filter_and(recentlyplayed_filter, played_filter)
    else:
        episodefilter = dict(recentlyplayed_filter)
        episodefilter['value'] = '%s' % recent_days
    return get_episodes(tvshow_id, 'lastplayed', False, episodefilter=episodefilter)

def get_recentlyadded_episodes(tvshow_id=None, recent_days=28):
    if recent_days == 28:
        episodefilter = recentlyadded_filter
    else:
        episodefilter = dict(recentlyadded_filter)
        episodefilter['value'] = '%s' % recent_days
    return get_episodes(tvshow_id, 'dateadded', False, episodefilter=episodefilter)

def get_first_unplayed_episode(tvshow_id):
    json_request = get_base_json_request('VideoLibrary.GetEpisodes')
    json_request['params']['tvshowid'] = tvshow_id
    json_request['params']['properties'] = episode_properties
    json_request['params']['sort'] = {'method': 'episode'}
    json_request['params']['filter'] = unplayed_filter
    json_request['params']['limits'] = {'end': 1}

    json_result = pykodi.execute_jsonrpc(json_request)

    if _check_json_result(json_result, 'episodes', json_request):
        return json_result['result']['episodes'][0]

def get_musicvideos(sort_method='sorttitle', ascending=True, limit=None, properties=None):
    json_request = get_base_json_request('VideoLibrary.GetMusicVideos')
    json_request['params']['properties'] = properties if properties is not None else musicvideos_properties
    json_request['params']['sort'] = {'method': sort_method, 'order': 'ascending' if ascending else 'descending'}
    if limit:
        json_request['params']['limits'] = {'end': limit}

    json_result = pykodi.execute_jsonrpc(json_request)
    if _check_json_result(json_result, 'musicvideos', json_request):
        return json_result['result']['musicvideos']
    else:
        return []

def get_seasons(tvshow_id):
    json_request = get_base_json_request('VideoLibrary.GetSeasons')
    json_request['params']['tvshowid'] = tvshow_id
    json_request['params']['properties'] = ['season', 'art']

    json_result = pykodi.execute_jsonrpc(json_request)

    if _check_json_result(json_result, 'seasons', json_request):
        return json_result['result']['seasons']
    else:
        return []

def set_tvshow_details(tvshow_id, **tvshow_details):
    json_request = get_base_json_request('VideoLibrary.SetTVShowDetails')
    json_request['params'] = tvshow_details
    json_request['params']['tvshowid'] = tvshow_id

    json_result = pykodi.execute_jsonrpc(json_request)
    if not _check_json_result(json_result, 'OK', json_request):
        log(json_result)

def set_season_details(season_id, **season_details):
    json_request = get_base_json_request('VideoLibrary.SetSeasonDetails')
    json_request['params'] = season_details
    json_request['params']['seasonid'] = season_id

    json_result = pykodi.execute_jsonrpc(json_request)
    if not _check_json_result(json_result, 'OK', json_request):
        log(json_result)

def set_episode_details(episode_id, **episode_details):
    json_request = get_base_json_request('VideoLibrary.SetEpisodeDetails')
    json_request['params'] = episode_details
    json_request['params']['episodeid'] = episode_id

    json_result = pykodi.execute_jsonrpc(json_request)
    if not _check_json_result(json_result, 'OK', json_request):
        log(json_result)

def set_movie_details(movie_id, **movie_details):
    json_request = get_base_json_request('VideoLibrary.SetMovieDetails')
    json_request['params'] = movie_details
    json_request['params']['movieid'] = movie_id

    json_result = pykodi.execute_jsonrpc(json_request)
    if not _check_json_result(json_result, 'OK', json_request):
        log(json_result)

def get_application_properties(properties):
    json_request = get_base_json_request('Application.GetProperties')
    json_request['params']['properties'] = properties
    json_result = pykodi.execute_jsonrpc(json_request)
    if _check_json_result(json_result, None, json_request):
        return json_result['result']

def jsonrpc_introspect():
    json_request = get_base_json_request('JSONRPC.Introspect')
    json_result = pykodi.execute_jsonrpc(json_request)
    log(json_result)

def get_base_json_request(method):
    return {'jsonrpc': '2.0', 'method': method, 'params': {}, 'id': 1}

def filter_and(*operator_args):
    return {'and': [arg for arg in operator_args if arg]}

def _check_json_result(json_result, result_key, json_request):
    if 'error' in json_result:
        raise JSONException(json_request, json_result)

    return 'result' in json_result and (not result_key or result_key in json_result['result'])

class JSONException(Exception):
    def __init__(self, json_request, json_result):
        self.json_request = json_request
        self.json_result = json_result

        message = "There was an error with a JSON-RPC request.\nRequest: "
        message += json.dumps(json_request, cls=pykodi.UTF8PrettyJSONEncoder)
        message += "\nResult: "
        message += json.dumps(json_result, cls=pykodi.UTF8PrettyJSONEncoder)

        super(JSONException, self).__init__(message)
