==============
 Contributors
==============

Huge thanks to all those folks who have helped improve CacheControl!

 - Toby White
 - Ian Cordasco
 - Cory Benfield
 - Javier de la Rosa
 - Donald Stufft
 - Joseph Walton
