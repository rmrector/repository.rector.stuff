Two images from the Noun Project are used in this add-on, both available under the [CC-BY license](http://creativecommons.org/licenses/by/3.0/us/).

[Scorpio](https://thenounproject.com/term/scorpio/207235) by Michelle Abrahall

[Clapperboard](https://thenounproject.com/term/clapperboard/223935) by Noe Araujo
