import collections
import os
import sys
import time
import urllib
import xbmc
import xbmcaddon
from datetime import datetime

if sys.version_info < (2, 7):
    import simplejson as json
else:
    import json

# First call isn't threadsafe, so do it on import, which hopefully happens on the main thread first
# http://bugs.python.org/issue7980
# Or something. Throwing it down as soon as possible helps, at least
datetime.strptime('2112-04-01', '%Y-%m-%d')

watch_addon_filter = ['*']

_log_level_tag_lookup = {
    xbmc.LOGDEBUG: 'D',
    xbmc.LOGINFO: 'I'
}

WINDOW_VIDEOS = 10025

_main_addon = None
def get_main_addon():
    global _main_addon
    if not _main_addon:
        _main_addon = Addon()
    return _main_addon

def get_infolabel(info_label):
    try:
        # WARN: Got a "RuntimeError: access_violation", when "Window.Property(xmlfile)" dropped right as Kodi was switching windows
        # And there is another one, this time "RuntimeError: Unknown exception", getting Window(home).Property(Movies.Count)
        return xbmc.getInfoLabel(info_label)
    except RuntimeError:
        log("RuntimeError with xbmc.getInfoLabel, sleeping and trying again", xbmc.LOGWARNING, 'script.module.devhelper')
        xbmc.sleep(50)
        # REVIEW: I have no idea if this actually helps
        return xbmc.getInfoLabel(info_label)

def get_conditional(conditional):
    return xbmc.getCondVisibility(conditional) == 1

def execute_builtin(builtin_command):
    xbmc.executebuiltin(builtin_command)

def execute_jsonrpc(jsonrpc_command):
    if isinstance(jsonrpc_command, dict):
        jsonrpc_command = json.dumps(jsonrpc_command)

    json_result = xbmc.executeJSONRPC(jsonrpc_command)
    return json.loads(json_result, cls=UTF8JSONDecoder)

def log(message, level=xbmc.LOGDEBUG, addonid=None, tag=None):
    if not addonid:
        addonid = get_main_addon().addonid
    if tag:
        addonid = addonid + ':' + tag
    if ('*' in watch_addon_filter or addonid in watch_addon_filter) and level < xbmc.LOGNOTICE:
        # Messages from this add-on are being watched, elevate to NOTICE so Kodi logs it
        level_tag = _log_level_tag_lookup[level] + ': ' if level in _log_level_tag_lookup else ''
        level = xbmc.LOGNOTICE
    else:
        level_tag = ''

    if isinstance(message, (dict, list, tuple)):
        if len(message) > 300:
            message = '%s' % message
        else:
            message = json.dumps(message, cls=UTF8PrettyJSONEncoder)

    if isinstance(message, unicode):
        message = message.encode('utf-8')
    elif not isinstance(message, str):
        message = str(message)

    file_message = '%s[%s] %s' % (level_tag, addonid, message)
    xbmc.log(file_message, level)

def get_language(language_format=xbmc.ENGLISH_NAME, region=False):
    language = xbmc.getLanguage(language_format, region)
    if not language:
        # empty for English on Jarvis
        if language_format == xbmc.ISO_639_1:
            language = 'en'
        elif language_format == xbmc.ISO_639_2:
            language = 'eng'
    return language

def unquoteimage(imagestring):
    if imagestring.startswith('image://'):
        return urllib.unquote(imagestring[8:-1])
    else:
        return imagestring

def get_pluginpath():
    path = sys.argv[0].split('://')[1].rstrip('/').split('/')[1:] # cuts out addon id
    query_list = sys.argv[2].lstrip('?').split('&&')
    query = {}
    if query_list and query_list[0]:
        for item in query_list:
            key, value = item.split("=")
            if key in query:
                if isinstance(query[key], list):
                    query[key].append(value)
                else:
                    query[key] = [query[key], value]
            else:
                query[key] = value

    return {'path': path, 'handle': int(sys.argv[1]), 'query': query}

def get_command(first_arg_key=None):
    '''Build a dictionary of all arguments. If first_arg_key is passed, the first argument can be passed without a key, and it will be stored with key first_arg_key. The rest are split key, value on '=' with the keys lowercased to ease comparison. Arguments without '=' are set to True with a lowercased key, handy for simply flipping on a switch or enabling an optional feature.'''
    command = {}
    start = 2 if first_arg_key else 1
    for x in range(start, len(sys.argv)):
        arg = sys.argv[x].split("=")
        command[arg[0].strip().lower()] = arg[1].strip() if len(arg) > 1 else True

    if first_arg_key:
        command[first_arg_key] = sys.argv[1]
    return command

class Addon(xbmcaddon.Addon):
    def __init__(self, *args, **kwargs):
        super(Addon, self).__init__()
        self.addonid = self.getAddonInfo('id')
        self.path = self.getAddonInfo('path')
        self.datapath = xbmc.translatePath('special://profile/addon_data/' + self.addonid).decode('utf-8')
        unicodepath = xbmc.translatePath(self.path).decode('utf-8')
        self.resourcespath = os.path.join(unicodepath, u'resources')
        if not self.resourcespath:
            self.resourcespath = None
            self.resourcelibs = None
        else:
            self.resourcelibs = os.path.join(unicodepath, u'resources', u'lib')
            if not os.path.isdir(self.resourcelibs):
                self.resourcelibs = None
        self.libs = os.path.join(unicodepath, u'lib')
        if not os.path.isdir(self.libs):
            self.libs = None

    def get_setting(self, settingid):
        result = self.getSetting(settingid)
        if result == 'true':
            result = True
        elif result == 'false':
            result = False
        elif settingid.endswith('_list'):
            result = result.split('|')
            if len(result) == 1 and not result[0]:
                result = []
        return result

    def set_setting(self, settingid, value):
        if settingid.endswith('_list') and not isinstance(value, basestring) and isinstance(value, collections.Iterable):
            value = '|'.join(value)
        elif not isinstance(value, basestring):
            value = str(value)
        self.setSetting(settingid, value)

class UTF8PrettyJSONEncoder(json.JSONEncoder):
    def __init__(self, *args, **kwargs):
        kwargs['skipkeys'] = True
        kwargs['ensure_ascii'] = False
        kwargs['indent'] = 2
        kwargs['separators'] = (',', ': ')
        super(UTF8PrettyJSONEncoder, self).__init__(*args, **kwargs)

    def default(self, obj):
        if isinstance(obj, collections.Mapping):
            return dict((key, obj[key]) for key in obj.keys())
        if isinstance(obj, collections.Iterable):
            return list(obj)
        if hasattr(obj, '__dict__'):
            return obj.__dict__
        return str(obj)

    def encode(self, obj):
        result = super(UTF8PrettyJSONEncoder, self).encode(obj)
        if isinstance(result, unicode):
            result = result.encode('utf-8')
        return result

    def iterencode(self, obj, _one_shot=False):
        for result in super(UTF8PrettyJSONEncoder, self).iterencode(obj, _one_shot):
            if isinstance(result, unicode):
                result = result.encode('utf-8')
            yield result

class UTF8JSONDecoder(json.JSONDecoder):
    def __init__(self, *args, **kwargs):
        super(UTF8JSONDecoder, self).__init__(*args, **kwargs)

    def raw_decode(self, s, idx=0):
        result, end = super(UTF8JSONDecoder, self).raw_decode(s)
        result = self._json_unicode_to_str(result)
        return result, end

    def _json_unicode_to_str(self, jsoninput):
        if isinstance(jsoninput, dict):
            return dict((self._json_unicode_to_str(key), self._json_unicode_to_str(value)) for key, value in jsoninput.iteritems())
        elif isinstance(jsoninput, list):
            return [self._json_unicode_to_str(item) for item in jsoninput]
        elif isinstance(jsoninput, unicode):
            return jsoninput.encode('utf-8')
        else:
            return jsoninput
