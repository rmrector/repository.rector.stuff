from collections import namedtuple

SortedDisplay = namedtuple('SortedDisplay', ['sort', 'display'])
