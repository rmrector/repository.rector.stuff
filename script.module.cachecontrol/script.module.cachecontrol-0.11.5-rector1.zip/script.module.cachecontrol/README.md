script.module.cachecontrol
======================

Python CacheControl library for Requests packed for KODI.
with rmcgibbo/stream PR merged to cache chunked responses

See https://github.com/ionrock/cachecontrol
