script.module.lockfile
======================

Python lockfile library packed for KODI.

See http://git.openstack.org/cgit/openstack/pylockfile

lockfile was recently deprecated in favor of fasteners or oslo.concurrency, but CacheControl still depends on lockfile, so that's what we've got.